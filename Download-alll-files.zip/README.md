# Quick Coding with Brackets 

This is the demo project to go along with Quick Coding with Brackets course. It is a cheat sheet for keyboard shortcuts and the how to use the editor on both a Mac and a PC. 

Each step or video will be tagged so you can follow along. 

